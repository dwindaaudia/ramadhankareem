﻿namespace AppdevTHW4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_teamList = new System.Windows.Forms.Label();
            this.lb_chooseCtry = new System.Windows.Forms.Label();
            this.lb_chooseTeam = new System.Windows.Forms.Label();
            this.lb_teamCountry = new System.Windows.Forms.Label();
            this.lb_teamName = new System.Windows.Forms.Label();
            this.lb_addingTeam = new System.Windows.Forms.Label();
            this.txt_teamCountry = new System.Windows.Forms.TextBox();
            this.txt_teamName = new System.Windows.Forms.TextBox();
            this.textBox_PlayerNumber = new System.Windows.Forms.TextBox();
            this.textBox_playerName = new System.Windows.Forms.TextBox();
            this.lb_playerNumber = new System.Windows.Forms.Label();
            this.lb_playerName = new System.Windows.Forms.Label();
            this.lb_addingPlayers = new System.Windows.Forms.Label();
            this.txt_teamCity = new System.Windows.Forms.TextBox();
            this.lb_teamCity = new System.Windows.Forms.Label();
            this.lb_playerPosition = new System.Windows.Forms.Label();
            this.comboBox_country = new System.Windows.Forms.ComboBox();
            this.bt_addingTeam = new System.Windows.Forms.Button();
            this.comboBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.comboBox_team = new System.Windows.Forms.ComboBox();
            this.listBox_players = new System.Windows.Forms.ListBox();
            this.bt_addingPlayers = new System.Windows.Forms.Button();
            this.button_remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_teamList
            // 
            this.lb_teamList.AutoSize = true;
            this.lb_teamList.Location = new System.Drawing.Point(60, 71);
            this.lb_teamList.Name = "lb_teamList";
            this.lb_teamList.Size = new System.Drawing.Size(132, 20);
            this.lb_teamList.TabIndex = 0;
            this.lb_teamList.Text = "Soccer Team List";
            // 
            // lb_chooseCtry
            // 
            this.lb_chooseCtry.AutoSize = true;
            this.lb_chooseCtry.Location = new System.Drawing.Point(60, 123);
            this.lb_chooseCtry.Name = "lb_chooseCtry";
            this.lb_chooseCtry.Size = new System.Drawing.Size(123, 20);
            this.lb_chooseCtry.TabIndex = 1;
            this.lb_chooseCtry.Text = "Choose Country";
            // 
            // lb_chooseTeam
            // 
            this.lb_chooseTeam.AutoSize = true;
            this.lb_chooseTeam.Location = new System.Drawing.Point(60, 168);
            this.lb_chooseTeam.Name = "lb_chooseTeam";
            this.lb_chooseTeam.Size = new System.Drawing.Size(108, 20);
            this.lb_chooseTeam.TabIndex = 2;
            this.lb_chooseTeam.Text = "Choose Team";
            // 
            // lb_teamCountry
            // 
            this.lb_teamCountry.AutoSize = true;
            this.lb_teamCountry.Location = new System.Drawing.Point(390, 168);
            this.lb_teamCountry.Name = "lb_teamCountry";
            this.lb_teamCountry.Size = new System.Drawing.Size(108, 20);
            this.lb_teamCountry.TabIndex = 7;
            this.lb_teamCountry.Text = "Team Country";
            // 
            // lb_teamName
            // 
            this.lb_teamName.AutoSize = true;
            this.lb_teamName.Location = new System.Drawing.Point(390, 123);
            this.lb_teamName.Name = "lb_teamName";
            this.lb_teamName.Size = new System.Drawing.Size(95, 20);
            this.lb_teamName.TabIndex = 6;
            this.lb_teamName.Text = "Team Name";
            // 
            // lb_addingTeam
            // 
            this.lb_addingTeam.AutoSize = true;
            this.lb_addingTeam.Location = new System.Drawing.Point(390, 71);
            this.lb_addingTeam.Name = "lb_addingTeam";
            this.lb_addingTeam.Size = new System.Drawing.Size(103, 20);
            this.lb_addingTeam.TabIndex = 5;
            this.lb_addingTeam.Text = "Adding Team";
            // 
            // txt_teamCountry
            // 
            this.txt_teamCountry.Location = new System.Drawing.Point(527, 163);
            this.txt_teamCountry.Name = "txt_teamCountry";
            this.txt_teamCountry.Size = new System.Drawing.Size(166, 26);
            this.txt_teamCountry.TabIndex = 9;
            // 
            // txt_teamName
            // 
            this.txt_teamName.Location = new System.Drawing.Point(527, 118);
            this.txt_teamName.Name = "txt_teamName";
            this.txt_teamName.Size = new System.Drawing.Size(166, 26);
            this.txt_teamName.TabIndex = 8;
            // 
            // textBox_PlayerNumber
            // 
            this.textBox_PlayerNumber.Location = new System.Drawing.Point(872, 163);
            this.textBox_PlayerNumber.Name = "textBox_PlayerNumber";
            this.textBox_PlayerNumber.Size = new System.Drawing.Size(166, 26);
            this.textBox_PlayerNumber.TabIndex = 14;
            // 
            // textBox_playerName
            // 
            this.textBox_playerName.Location = new System.Drawing.Point(872, 118);
            this.textBox_playerName.Name = "textBox_playerName";
            this.textBox_playerName.Size = new System.Drawing.Size(166, 26);
            this.textBox_playerName.TabIndex = 13;
            // 
            // lb_playerNumber
            // 
            this.lb_playerNumber.AutoSize = true;
            this.lb_playerNumber.Location = new System.Drawing.Point(730, 168);
            this.lb_playerNumber.Name = "lb_playerNumber";
            this.lb_playerNumber.Size = new System.Drawing.Size(112, 20);
            this.lb_playerNumber.TabIndex = 12;
            this.lb_playerNumber.Text = "Player Number";
            // 
            // lb_playerName
            // 
            this.lb_playerName.AutoSize = true;
            this.lb_playerName.Location = new System.Drawing.Point(730, 123);
            this.lb_playerName.Name = "lb_playerName";
            this.lb_playerName.Size = new System.Drawing.Size(98, 20);
            this.lb_playerName.TabIndex = 11;
            this.lb_playerName.Text = "Player Name";
            // 
            // lb_addingPlayers
            // 
            this.lb_addingPlayers.AutoSize = true;
            this.lb_addingPlayers.Location = new System.Drawing.Point(730, 71);
            this.lb_addingPlayers.Name = "lb_addingPlayers";
            this.lb_addingPlayers.Size = new System.Drawing.Size(114, 20);
            this.lb_addingPlayers.TabIndex = 10;
            this.lb_addingPlayers.Text = "Adding Players";
            // 
            // txt_teamCity
            // 
            this.txt_teamCity.Location = new System.Drawing.Point(527, 207);
            this.txt_teamCity.Name = "txt_teamCity";
            this.txt_teamCity.Size = new System.Drawing.Size(166, 26);
            this.txt_teamCity.TabIndex = 16;
            // 
            // lb_teamCity
            // 
            this.lb_teamCity.AutoSize = true;
            this.lb_teamCity.Location = new System.Drawing.Point(390, 212);
            this.lb_teamCity.Name = "lb_teamCity";
            this.lb_teamCity.Size = new System.Drawing.Size(79, 20);
            this.lb_teamCity.TabIndex = 15;
            this.lb_teamCity.Text = "Team City";
            // 
            // lb_playerPosition
            // 
            this.lb_playerPosition.AutoSize = true;
            this.lb_playerPosition.Location = new System.Drawing.Point(730, 214);
            this.lb_playerPosition.Name = "lb_playerPosition";
            this.lb_playerPosition.Size = new System.Drawing.Size(112, 20);
            this.lb_playerPosition.TabIndex = 17;
            this.lb_playerPosition.Text = "Player Position";
            // 
            // comboBox_country
            // 
            this.comboBox_country.FormattingEnabled = true;
            this.comboBox_country.Location = new System.Drawing.Point(200, 118);
            this.comboBox_country.Name = "comboBox_country";
            this.comboBox_country.Size = new System.Drawing.Size(166, 28);
            this.comboBox_country.TabIndex = 19;
            this.comboBox_country.SelectedIndexChanged += new System.EventHandler(this.comboBox_country_SelectedIndexChanged);
            // 
            // bt_addingTeam
            // 
            this.bt_addingTeam.Location = new System.Drawing.Point(527, 254);
            this.bt_addingTeam.Name = "bt_addingTeam";
            this.bt_addingTeam.Size = new System.Drawing.Size(99, 32);
            this.bt_addingTeam.TabIndex = 20;
            this.bt_addingTeam.Text = "Add";
            this.bt_addingTeam.UseVisualStyleBackColor = true;
            this.bt_addingTeam.Click += new System.EventHandler(this.bt_addingTeam_Click);
            // 
            // comboBox_PlayerPosition
            // 
            this.comboBox_PlayerPosition.FormattingEnabled = true;
            this.comboBox_PlayerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.comboBox_PlayerPosition.Location = new System.Drawing.Point(872, 204);
            this.comboBox_PlayerPosition.Name = "comboBox_PlayerPosition";
            this.comboBox_PlayerPosition.Size = new System.Drawing.Size(166, 28);
            this.comboBox_PlayerPosition.TabIndex = 21;
            // 
            // comboBox_team
            // 
            this.comboBox_team.FormattingEnabled = true;
            this.comboBox_team.Location = new System.Drawing.Point(200, 161);
            this.comboBox_team.Name = "comboBox_team";
            this.comboBox_team.Size = new System.Drawing.Size(166, 28);
            this.comboBox_team.TabIndex = 22;
            this.comboBox_team.SelectedIndexChanged += new System.EventHandler(this.comboBox_team_SelectedIndexChanged);
            // 
            // listBox_players
            // 
            this.listBox_players.FormattingEnabled = true;
            this.listBox_players.ItemHeight = 20;
            this.listBox_players.Location = new System.Drawing.Point(64, 231);
            this.listBox_players.Name = "listBox_players";
            this.listBox_players.Size = new System.Drawing.Size(301, 124);
            this.listBox_players.TabIndex = 23;
            // 
            // bt_addingPlayers
            // 
            this.bt_addingPlayers.Location = new System.Drawing.Point(872, 254);
            this.bt_addingPlayers.Name = "bt_addingPlayers";
            this.bt_addingPlayers.Size = new System.Drawing.Size(99, 32);
            this.bt_addingPlayers.TabIndex = 24;
            this.bt_addingPlayers.Text = "Add";
            this.bt_addingPlayers.UseVisualStyleBackColor = true;
            this.bt_addingPlayers.Click += new System.EventHandler(this.bt_addingPlayers_Click);
            // 
            // button_remove
            // 
            this.button_remove.Location = new System.Drawing.Point(64, 372);
            this.button_remove.Name = "button_remove";
            this.button_remove.Size = new System.Drawing.Size(99, 32);
            this.button_remove.TabIndex = 25;
            this.button_remove.Text = "Remove";
            this.button_remove.UseVisualStyleBackColor = true;
            this.button_remove.Click += new System.EventHandler(this.button_remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 463);
            this.Controls.Add(this.button_remove);
            this.Controls.Add(this.bt_addingPlayers);
            this.Controls.Add(this.listBox_players);
            this.Controls.Add(this.comboBox_team);
            this.Controls.Add(this.comboBox_PlayerPosition);
            this.Controls.Add(this.bt_addingTeam);
            this.Controls.Add(this.comboBox_country);
            this.Controls.Add(this.lb_playerPosition);
            this.Controls.Add(this.txt_teamCity);
            this.Controls.Add(this.lb_teamCity);
            this.Controls.Add(this.textBox_PlayerNumber);
            this.Controls.Add(this.textBox_playerName);
            this.Controls.Add(this.lb_playerNumber);
            this.Controls.Add(this.lb_playerName);
            this.Controls.Add(this.lb_addingPlayers);
            this.Controls.Add(this.txt_teamCountry);
            this.Controls.Add(this.txt_teamName);
            this.Controls.Add(this.lb_teamCountry);
            this.Controls.Add(this.lb_teamName);
            this.Controls.Add(this.lb_addingTeam);
            this.Controls.Add(this.lb_chooseTeam);
            this.Controls.Add(this.lb_chooseCtry);
            this.Controls.Add(this.lb_teamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_teamList;
        private System.Windows.Forms.Label lb_chooseCtry;
        private System.Windows.Forms.Label lb_chooseTeam;
        private System.Windows.Forms.Label lb_teamCountry;
        private System.Windows.Forms.Label lb_teamName;
        private System.Windows.Forms.Label lb_addingTeam;
        private System.Windows.Forms.TextBox txt_teamCountry;
        private System.Windows.Forms.TextBox txt_teamName;
        private System.Windows.Forms.TextBox textBox_PlayerNumber;
        private System.Windows.Forms.TextBox textBox_playerName;
        private System.Windows.Forms.Label lb_playerNumber;
        private System.Windows.Forms.Label lb_playerName;
        private System.Windows.Forms.Label lb_addingPlayers;
        private System.Windows.Forms.TextBox txt_teamCity;
        private System.Windows.Forms.Label lb_teamCity;
        private System.Windows.Forms.Label lb_playerPosition;
        private System.Windows.Forms.ComboBox comboBox_country;
        private System.Windows.Forms.Button bt_addingTeam;
        private System.Windows.Forms.ComboBox comboBox_PlayerPosition;
        private System.Windows.Forms.ComboBox comboBox_team;
        private System.Windows.Forms.ListBox listBox_players;
        private System.Windows.Forms.Button bt_addingPlayers;
        private System.Windows.Forms.Button button_remove;
    }
}

