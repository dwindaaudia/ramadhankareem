﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AppdevTHW4
{
    public partial class Form1 : Form
    {
        private List<Team> teams;

        public Form1()
        {
            InitializeComponent();
        }

        private void listTeams()
        {
            listBox_players.Sorted = true;
            teams = new List<Team>();
            Team team = new Team
            {
                teamCity = "Fulham",
                teamCountry = "England",
                teamName = "Chelsea"
            };
            team.tambahPlayer("Kepa Arrizabalaga", "01", "GK");
            team.tambahPlayer("Benoît Badiashile", "04", "DF");
            team.tambahPlayer("Enzo Fernández", "05", "MF");
            team.tambahPlayer("Thiago Silva", "06", "DF");
            team.tambahPlayer("N'Golo Kanté", "07", "MF");
            team.tambahPlayer("Mateo Kovačić", "08", "MF");
            team.tambahPlayer("Pierre-Emerick Aubameyang", "09", "FW");
            team.tambahPlayer("Christian Pulisic", "10", "MF");
            team.tambahPlayer("João Félix", "11", "FW");
            team.tambahPlayer("Ruben Loftus-Cheek", "12", "MF");
            team.tambahPlayer("Raheem Sterling", "17", "MF");
            teams.Add(team);
            team = new Team
            {
                teamCity = "Manchaster",
                teamCountry = "England",
                teamName = "Manchaster United"
            };
            team.tambahPlayer("David De Gea", "01", "GK");
            team.tambahPlayer("Victor Lindelof", "02", "DF");
            team.tambahPlayer("Phil Jones", "04", "DF");
            team.tambahPlayer("Harry Maguire", "05", "DF");
            team.tambahPlayer("Lisandro Martinez", "06", "DF");
            team.tambahPlayer("Bruno Fernandez", "08", "MF");
            team.tambahPlayer("Anthony Martial", "09", "FW");
            team.tambahPlayer("Marcus Rashford", "10", "FW");
            team.tambahPlayer("Tyrell Malacia", "12", "DF");
            team.tambahPlayer("Christian Eriksen", "14", "MF");
            team.tambahPlayer("Casemiro", "18", "MF");
            teams.Add(team);
            team = new Team
            {
                teamCity = "Munich",
                teamCountry = "Germany",
                teamName = "Bayern Munich"
            };
            team.tambahPlayer("Manuel Neuer", "01", "GK");
            team.tambahPlayer("Dayot Upamecano", "02", "DF");
            team.tambahPlayer("Matthijs de Ligt", "04", "DF");
            team.tambahPlayer("Benjamin Pavard", "05", "DF");
            team.tambahPlayer("Joshua Kimmich", "06", "MF");
            team.tambahPlayer("Serge Gnabry", "07", "FW");
            team.tambahPlayer("Leon Goretzka", "08", "MF");
            team.tambahPlayer("Leroy Sané", "10", "FW");
            team.tambahPlayer("Thomas Müller ", "25", "FW");
            team.tambahPlayer("Paul Wanner", "14", "MF");
            team.tambahPlayer("Lucas Hernandez", "21", "DF");
            teams.Add(team);
        }

        private void tambahCountry()
        {
            comboBox_country.Items.Clear();
            foreach (Team team in teams)
            {
                if (!comboBox_country.Items.Contains(team.teamCountry))
                {
                    comboBox_country.Items.Add(team.teamCountry);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listTeams();
            tambahCountry();
        }

        private void comboBox_country_SelectionChangeCommitted(object sender, EventArgs e)
        {
            comboBox_team.Items.Clear();
            string a = comboBox_country.SelectedItem.ToString();
            foreach (Team team in teams)
            {
                if (team.teamCountry == a)
                {
                    comboBox_team.Items.Add(team.teamName);
                }
            }
        }

        private void comboBox_team_SelectionChangeCommitted(object sender, EventArgs e)
        {
            listBox_players.Items.Clear();
            string team = comboBox_team.SelectedItem.ToString();
            addListPlayer(team);
        }

        private void addListPlayer(string newTeam)
        {
            listBox_players.Items.Clear();
            Team team = null;
            foreach (Team tteam in teams)
            {
                if (tteam.teamName == newTeam)
                {
                    team = tteam;
                }
            }
            List<Player> players = team.GetPlayers();
            foreach (Player p in players)
            {
                listBox_players.Items.Add("(" + p.playerNumber + ") " + p.playerName + ", " + p.playerPosition);
            }
        }

        private void bt_addingPlayers_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox_playerName.Text) && !string.IsNullOrEmpty(textBox_PlayerNumber.Text) && comboBox_PlayerPosition.SelectedIndex != -1)
            {
                string pilih = comboBox_team.SelectedItem.ToString();
                foreach (Team team in teams)
                {
                    if (!team.teamName.Equals(pilih))
                    {
                        continue;
                    }
                    List<Player> players = team.GetPlayers();
                    bool yes = false;
                    foreach (Player p in players)
                    {
                        if (p.playerNumber == textBox_PlayerNumber.Text)
                        {
                            yes = true;
                            break;
                        }
                    }
                    if (!yes)
                    {
                        team.tambahPlayer((textBox_playerName).Text, (textBox_PlayerNumber).Text, comboBox_PlayerPosition.Text.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Player with same number is found", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
                    }
                }
                addListPlayer(pilih);
                comboBox_PlayerPosition.Text = string.Empty;
                textBox_playerName.Clear();
                textBox_PlayerNumber.Clear();
            }
            else
            {
                MessageBox.Show("All fields need to be filled", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
            }
        }

        private void button_remove_Click(object sender, EventArgs e)
        {
            string text = comboBox_team.SelectedItem.ToString();
            foreach (Team team in teams)
            {
                if (!(team.teamName == text))
                {
                    continue;
                }
                List<Player> players = team.GetPlayers();
                if (players.Count > 11)
                {
                    string[] array = listBox_players.SelectedItem.ToString().Split(new char[1] { ',' });
                    string[] array2 = array[0].Split(new char[1] { ' ' });
                    string[] array3 = array2[0].Split(new char[1] { '(' });
                    string[] array4 = array3[1].Split(new char[1] { ')' });
                    string nomorPemain = array4[0];
                    string namaPemain = "";
                    for (int i = 1; i < array2.Length; i++)
                    {
                        namaPemain += array2[i];
                        if (i != array2.Length - 1)
                        {
                            namaPemain += " ";
                        }
                    }
                    team.removePlayer(namaPemain, nomorPemain);
                }
                else
                {
                    MessageBox.Show("Unable to remove players if players less than equal 11", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
                }
            }
            addListPlayer(text);
        }

        private void updateCmbTeam()
        {
            comboBox_team.Items.Clear();
            string text = comboBox_country.SelectedItem.ToString();
            foreach (Team team in teams)
            {
                if (team.teamCountry == text)
                {
                    comboBox_team.Items.Add(team.teamName);
                }
            }
        }

        private void bt_addingTeam_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_teamName.Text) && !string.IsNullOrEmpty(txt_teamCity.Text) && !string.IsNullOrEmpty(txt_teamCountry.Text))
            {
                string text = txt_teamName.Text;
                string text2 = txt_teamCountry.Text;
                string text3 = txt_teamCity.Text;
                bool yes = false;
                foreach (Team team in teams)
                {
                    if (team.teamName == text)
                    {
                        yes = true;
                        break;
                    }
                }
                if (!yes)
                {
                    teams.Add(new Team
                    {
                        teamName = text,
                        teamCity = text3,
                        teamCountry = text2
                    });    
                }
                tambahCountry();
                txt_teamName.Clear();
                txt_teamCity.Clear();
                txt_teamCountry.Clear();
            }
            else
            {
                MessageBox.Show("All fields need to be filled", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
            }
        }

        private void comboBox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox_players.Items.Clear();
            string team = comboBox_team.SelectedItem.ToString();
            addListPlayer(team);
        }

        private void comboBox_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox_team.Items.Clear();
            string a = comboBox_country.SelectedItem.ToString();
            foreach (Team team in teams)
            {
                if (team.teamCountry == a)
                {
                    comboBox_team.Items.Add(team.teamName);
                }
            }
        }
    }
}



    

