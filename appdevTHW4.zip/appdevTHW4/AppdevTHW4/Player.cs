﻿
public class Player
{
    public string playerName { get; set; }

    public string playerNumber { get; set; }

    public string playerPosition { get; set; }

}

