﻿using System;
using System.Collections.Generic;

public class Team
{
    public string teamName {  get; set; }
    public string teamCountry { get; set; }
    public string teamCity { get; set; }

    private List<Player> PlayerList = new List<Player>();

    public void tambahPlayer (string name, string nomor, string posisi)
    {
        PlayerList.Add(new Player
        {
            playerName = name,
            playerNumber = nomor,
            playerPosition = posisi,
        });
    }

    public void removePlayer (string name, string nomor)
    {
        foreach (Player player in PlayerList)
        {
            if (player.playerName == name)
            {
                PlayerList.Remove(player);
                break;
            }
        }
    }

    public List<Player> GetPlayers()
    {
        return PlayerList;
    }

    public void SetPlayer (List<Player> list)
    {
        PlayerList = list;
    }
}

